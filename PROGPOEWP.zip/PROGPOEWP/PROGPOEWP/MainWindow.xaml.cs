﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PROGPOEWP
{
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<Recipe>();
            DisplayRecipes(recipes);
        }

        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = IngredientTextBox.Text.ToLower();
            string foodGroup = (FoodGroupComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
            if (foodGroup == "All") foodGroup = null;
            double maxCalories;
            double.TryParse(MaxCaloriesTextBox.Text, out maxCalories);

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (string.IsNullOrEmpty(foodGroup) || r.Ingredients.Any(i => i.FoodGroup == foodGroup)) &&
                (string.IsNullOrEmpty(MaxCaloriesTextBox.Text) || r.CalculateTotalCalories() <= maxCalories)).ToList();

            DisplayRecipes(filteredRecipes);
        }

        private void ClearFilters_Click(object sender, RoutedEventArgs e)
        {
            IngredientTextBox.Clear();
            FoodGroupComboBox.SelectedIndex = 0; // Reset to "All"
            MaxCaloriesTextBox.Clear();
            DisplayRecipes(recipes);
        }

        private void DisplayRecipes(IEnumerable<Recipe> recipes)
        {
            RecipesListBox.ItemsSource = recipes.ToList();
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            string name = Prompt.ShowDialog("Enter the name of the recipe:", "New Recipe");
            if (string.IsNullOrEmpty(name)) return;

            Recipe recipe = new Recipe(name);
            if (PromptRecipeDetails(recipe))
            {
                recipe.CaloriesExceeded += Recipe_CaloriesExceeded;
                recipe.SaveOriginalQuantities();
                recipes.Add(recipe);
                DisplayRecipes(recipes);
            }
        }

        private bool PromptRecipeDetails(Recipe recipe)
        {
            try
            {
                int ingredientCount = int.Parse(Prompt.ShowDialog("How many ingredients will you be using?", "Ingredients Count"));
                for (int i = 0; i < ingredientCount; i++)
                {
                    Ingredient ingredient = new Ingredient
                    {
                        Name = Prompt.ShowDialog($"Enter ingredient {i + 1} name:", "Ingredient Name"),
                        Quantity = double.Parse(Prompt.ShowDialog($"Enter the quantity for ingredient {i + 1}:", "Ingredient Quantity")),
                        Unit = Prompt.ShowDialog($"Enter the unit of measurement for ingredient {i + 1}:", "Unit of Measurement"),
                        Calories = double.Parse(Prompt.ShowDialog($"Enter the number of calories for ingredient {i + 1}:", "Calories")),
                        FoodGroup = Prompt.ShowDialog($"Enter the food group for ingredient {i + 1}:", "Food Group")
                    };
                    recipe.Ingredients.Add(ingredient);
                }

                int stepCount = int.Parse(Prompt.ShowDialog("How many steps will there be in the recipe?", "Steps Count"));
                for (int i = 0; i < stepCount; i++)
                {
                    Step step = new Step
                    {
                        Description = Prompt.ShowDialog($"Enter step {i + 1} description:", "Step Description")
                    };
                    recipe.Steps.Add(step);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error entering recipe details: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private void Recipe_CaloriesExceeded(string recipeName)
        {
            MessageBox.Show($"The recipe \"{recipeName}\" exceeds 300 calories!", "Calories Exceeded", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void DisplaySelectedRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectedRecipe)
            {
                DisplayRecipe(selectedRecipe);
            }
        }

        private void DisplayRecipe(Recipe recipe)
        {
            MessageBox.Show(recipe.GetDetails(), "Recipe Details", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ClearAllRecipes_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            DisplayRecipes(recipes);
            MessageBox.Show("All recipes have been cleared.", "Cleared", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectedRecipe)
            {
                if (double.TryParse(ScaleFactorTextBox.Text, out double scaleFactor))
                {
                    selectedRecipe.Scale(scaleFactor);
                    DisplayRecipe(selectedRecipe);
                }
                else
                {
                    MessageBox.Show("Please enter a valid scale factor.", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a recipe to scale.", "No Recipe Selected", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectedRecipe)
            {
                selectedRecipe.ResetQuantities();
                DisplayRecipe(selectedRecipe);
            }
            else
            {
                MessageBox.Show("Please select a recipe to reset quantities.", "No Recipe Selected", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    // Class for an ingredient
    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    // Class for a step in the recipe
    public class Step
    {
        public string Description { get; set; }
    }

    // Class for a recipe
    public class Recipe
    {
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }
        public string Name { get; set; }
        public event Action<string> CaloriesExceeded;
        private List<Ingredient> originalIngredients;

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
            originalIngredients = new List<Ingredient>();
        }

        public double CalculateTotalCalories()
        {
            return Ingredients.Sum(i => i.Calories);
        }

        public void Display()
        {
            MessageBox.Show(GetDetails(), "Recipe Details", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public string GetDetails()
        {
            string details = $"Recipe: {Name}\nIngredients:\n";
            foreach (var ingredient in Ingredients)
            {
                details += $"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories, {ingredient.FoodGroup})\n";
            }

            details += "Steps:\n";
            for (int i = 0; i < Steps.Count; i++)
            {
                details += $"{i + 1}. {Steps[i].Description}\n";
            }

            double totalCalories = CalculateTotalCalories();
            details += $"Total Calories: {totalCalories}";
            if (totalCalories > 300)
            {
                CaloriesExceeded?.Invoke(Name);
            }

            return details;
        }

        public void Scale(double factor)
        {
            foreach (var ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        public void ResetQuantities()
        {
            Ingredients = originalIngredients.Select(i => new Ingredient
            {
                Name = i.Name,
                Quantity = i.Quantity,
                Unit = i.Unit,
                Calories = i.Calories,
                FoodGroup = i.FoodGroup
            }).ToList();
        }

        public void SaveOriginalQuantities()
        {
            originalIngredients = Ingredients.Select(i => new Ingredient
            {
                Name = i.Name,
                Quantity = i.Quantity,
                Unit = i.Unit,
                Calories = i.Calories,
                FoodGroup = i.FoodGroup
            }).ToList();
        }
    }

    // Helper class for prompts
    public static class Prompt
    {
        public static string ShowDialog(string text, string caption)
        {
            Window prompt = new Window()
            {
                Width = 300,
                Height = 200,
                Title = caption
            };
            StackPanel stackPanel = new StackPanel();
            TextBlock textBlock = new TextBlock() { Text = text };
            TextBox textBox = new TextBox();
            Button confirmation = new Button() { Content = "OK", IsDefault = true, IsCancel = true };

            confirmation.Click += (sender, e) => { prompt.DialogResult = true; prompt.Close(); };
            stackPanel.Children.Add(textBlock);
            stackPanel.Children.Add(textBox);
            stackPanel.Children.Add(confirmation);
            prompt.Content = stackPanel;
            prompt.ShowDialog();

            return textBox.Text;
        }
    }
}
